# basic_webpage_template
A minimal webpage template
